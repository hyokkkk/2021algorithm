#include "select.hpp"

using namespace std;

int randomized_select(vector<int> &arr, int i) { return -1; }

int linear_select(vector<int> &arr, int i) { return -1; }

bool check(vector<int> &arr, int i, int x) { return false; }
